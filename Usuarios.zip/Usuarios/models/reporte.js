
module.exports = class Reporte {

    constructor(
        id,
        group,
        ruc,
        name,
        mail,
        accountEnabled

    )
    
    {
        this.id = id;
        this.group = group;
        this.ruc = ruc;
        this.name = name;
        this.mail = mail;
        this.accountEnabled = accountEnabled;
    }

}