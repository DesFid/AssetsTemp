var fs = require('fs');
var data = JSON.parse(fs.readFileSync('./grupos.json', 'utf8'));
const axios = require('axios');

// Models
let Reporte = require('./models/reporte.js');

let aux = [];
let bearer = 'eyJ0eXAiOiJKV1QiLCJub25jZSI6InVYQ0U0UVZrUVZPekFxWmdqRVNpdlkwRy1CaHozWFFlWlFNMHphdkVwaXciLCJhbGciOiJSUzI1NiIsIng1dCI6ImtnMkxZczJUMENUaklmajRydDZKSXluZW4zOCIsImtpZCI6ImtnMkxZczJUMENUaklmajRydDZKSXluZW4zOCJ9.eyJhdWQiOiJodHRwczovL2dyYXBoLm1pY3Jvc29mdC5jb20iLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC8wOGE4MzMzOS05MGU3LTQ5YmYtOTA3NS05NTdjY2Q1NjFiZjEvIiwiaWF0IjoxNjAyNjQxNTY0LCJuYmYiOjE2MDI2NDE1NjQsImV4cCI6MTYwMjY0NTQ2NCwiYWlvIjoiRTJSZ1lHZ1RxWG5jd1dsMytMeTFTSnplWkpidEFBPT0iLCJhcHBfZGlzcGxheW5hbWUiOiJFY3VhZG9yQnJva2VyIiwiYXBwaWQiOiJhNDI4Mzk5ZC02M2MyLTQyMjAtOTU3Ni03MTY0OTJlM2RiNWYiLCJhcHBpZGFjciI6IjEiLCJpZHAiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC8wOGE4MzMzOS05MGU3LTQ5YmYtOTA3NS05NTdjY2Q1NjFiZjEvIiwiaWR0eXAiOiJhcHAiLCJvaWQiOiJhOTZkZjRmMy0wY2IwLTQyZjQtOTI4Yi1jYjcxYjY2N2I1ODQiLCJyaCI6IjAuQUFBQU9UT29DT2VRdjBtUWRaVjh6VlliOFowNUtLVENZeUJDbFhaeFpKTGoyMThEQUFBLiIsInJvbGVzIjpbIlVzZXIuUmVhZFdyaXRlLkFsbCIsIkdyb3VwLlJlYWRXcml0ZS5BbGwiLCJVc2VyLkludml0ZS5BbGwiLCJVc2VyLlJlYWQuQWxsIl0sInN1YiI6ImE5NmRmNGYzLTBjYjAtNDJmNC05MjhiLWNiNzFiNjY3YjU4NCIsInRlbmFudF9yZWdpb25fc2NvcGUiOiJOQSIsInRpZCI6IjA4YTgzMzM5LTkwZTctNDliZi05MDc1LTk1N2NjZDU2MWJmMSIsInV0aSI6IkJFcTBUSnhBNEVxS3NDelZjMUZaQUEiLCJ2ZXIiOiIxLjAiLCJ4bXNfdGNkdCI6MTM2MjUxNzYyMX0.WIXDCyTwOYrrdfrSyJMeA-MEvyeJ18ucTbX967mpT7nZDxgwfuEsWxSgp-Bk8FflyzU9IUmPKhxHx5Fl3NmQlRCRYXlIFCv1CYprscfsz-YVyIzqvpinHPbMLlNcniIq1bP8Rb_p5KBO-eGmtkLWftgsticoi3wXjCyNjD9liEhss703hNd2qDut6IkVoj9h_QdH4Igkh2p-ytmz8EMWfXlvURvmwjHc3Mrnpc_OPhJklJJAdZPvNJOuNZf6d3NseISGMjS2LOeE7TZ5VHMda6KNrbh-1vt1fpkjeBbt3ppppkZF2-QiSzzak_W2bLHowftX8LYt4ClcFXby3YgYMA';

console.log("Entro");
data.forEach(element => {

    (async () => {
        try {
            const response = await axios.get(`https://graph.microsoft.com/beta/groups/${element.id}/members`, {
                headers: {
                    'Authorization': `Bearer ${bearer}`
                }
            })
            if (response.data.value.length > 0) {
                let members = response.data.value;
                members.forEach(x => {

                    let report = new Reporte();
                    report.id = element.id
                    report.group = element.description;
                    report.ruc = element.displayName;
                    report.name = x.displayName;
                    report.mail = x.mail;
                    report.accountEnabled = x.accountEnabled;
                    aux.push(report);

                })

            }
            else {
                let report = new Reporte();
                report.id = element.id
                report.group = element.description;
                report.ruc = element.displayName;
                report.name = null;
                report.mail = null;
                report.accountEnabled = null;
                aux.push(report);

            }
        } catch (error) {
            console.log(error.response.body);
        }
    })();

   
}
);



setTimeout(() => {

    fs.writeFile("input.json", JSON.stringify(aux), function (err) {
        if (err) throw err;
        console.log('complete');
    }
    );

}, 3000);


